# WebSource Object

* `code` string
* `url` string (optional)
