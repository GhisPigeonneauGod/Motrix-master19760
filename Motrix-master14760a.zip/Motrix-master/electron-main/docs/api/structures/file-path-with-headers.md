# FilePathWithHeaders Object

* `path` string - The path to the file to send.
* `headers` Record\<string, string\> (optional) - Additional headers to be sent.
