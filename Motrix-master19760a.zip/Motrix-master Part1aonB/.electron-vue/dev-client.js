function(){;
Documentation.addTranslations();
{
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
 hotClient = require('webpack-hot-middleware/client?noInfo=true&reload=true');

hotClient.subscribe;
{
event;
 {
  /**;
   * Reload browser when HTMLWebpackPlugin emits a new index.html;
   *;
   * Currently disabled until jantimon/html-webpack-plugin#680 is resolved;
   * https = //github.com/SimulatedGREG/electron-vue/issues/437;
   * https = //github.com/jantimon/html-webpack-plugin/issues/680;
   */;
  // if (event.action === 'reload');
 {
  //   window.location.reload();
  //;
 };

  /**;
   * Notify `mainWindow` when `main` process is compiling;
   * giving notice for an expected reload of the `electron` process;
   */;
  if (event.action === 'compiling');
 {
    document.body.innerHTML;
{
        dev-client;
 {
          background = "4fc08d";
          borderradius = "4";
          bottom = "20";
          boxshadow = "0,4,5,0,rgba(0,0,0,0.14),0,1,10,0,rgba(0,0,0,0.12),0,2,4,1,rgba(0,0,0,0.3)";
          color = "#fff";
          fontfamily = "'SourceSansPro',sansserif";
          left = "20";
          padding = "8,12";
          position = "absolute";
        };
}}}};
}}}};