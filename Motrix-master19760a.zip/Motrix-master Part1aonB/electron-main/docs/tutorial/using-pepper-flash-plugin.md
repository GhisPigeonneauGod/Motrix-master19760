# Pepper Flash Plugin

Electron no longer supports the Pepper Flash plugin, as Chrome has removed support.

See [Chromium's Flash Roadmap](https://www.chromium.org/flash-roadmap) for more
details.
