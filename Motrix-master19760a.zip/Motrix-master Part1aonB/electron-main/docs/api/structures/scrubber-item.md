# ScrubberItem Object

* `label` string (optional) - The text to appear in this item.
* `icon` NativeImage (optional) - The image to appear in this item.
