# OpenExternalPermissionRequest Object extends `PermissionRequest`

* `externalURL` string (optional) - The url of the `openExternal` request.
