# UserDefaultTypes Object

* `string` string
* `boolean` boolean
* `integer` number
* `float` number
* `double` number
* `url` string
* `array` Array\<unknown>
* `dictionary` Record\<string, unknown>

This type is a helper alias, no object will ever exist of this type.
