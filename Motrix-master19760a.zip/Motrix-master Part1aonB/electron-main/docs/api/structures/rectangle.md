# Rectangle Object

* `x` number - The x coordinate of the origin of the rectangle (must be an integer).
* `y` number - The y coordinate of the origin of the rectangle (must be an integer).
* `width` number - The width of the rectangle (must be an integer).
* `height` number - The height of the rectangle (must be an integer).
