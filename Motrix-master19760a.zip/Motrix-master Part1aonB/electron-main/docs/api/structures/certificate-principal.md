# CertificatePrincipal Object

* `commonName` string - Common Name.
* `organizations` string[] - Organization names.
* `organizationUnits` string[] - Organization Unit names.
* `locality` string - Locality.
* `state` string - State or province.
* `country` string - Country or region.
