const { autoUpdater } = process._linkedBinding('electron_browser_auto_updater');

export default autoUpdater;
